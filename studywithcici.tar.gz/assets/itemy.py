# -*- coding: utf-8 -*-
# pygame-exe --py312
import asyncio
import pygame as pg

pg.init()

class Item:
    def __init__(self,nazev:str,typ:str,cena:int,pozice:tuple,pohyblivost:bool,obrazek,obrazek_shop,owned:bool,equiped:bool):
        self.nazev = nazev
        self.typ = typ 
        self.cena = cena
        self.pozice = pozice          # (x, y)
        self.pohyblivost = pohyblivost
        self.obrazek = obrazek        # už načtený surface
        self.obrazek_shop = obrazek_shop
        self.owned = owned
        self.equiped = equiped

        # vytvoří rect podle obrázku
        self.rect = self.obrazek.get_rect()
        self.rect.topleft = self.pozice
        
        self.shop_rect = self.obrazek_shop.get_rect()

    def draw(self,pozice:tuple,surface,shop:bool = True,stred:bool = False, ):
     
        if shop:
            self.shop_rect.topleft = pozice
            obrazek = self.obrazek_shop
            surface.blit(obrazek,self.shop_rect)
        else:
            self.rect.topleft = pozice
            obrazek = self.obrazek
            surface.blit(obrazek,self.rect)
        
    def buy(self, aktualni_coins:int):
        if self.owned:
            return False, aktualni_coins, "Už vlastníš tento item"

        elif aktualni_coins >= self.cena:
            aktualni_coins -= self.cena
            self.owned = True
            return True, aktualni_coins, "Úspěšně zakoupeno"
        else:
            return False, aktualni_coins, "Nedostatek coinů"
        
    def fit_into_rect(self,image:pg.image, max_width, max_height):
        original_width = image.get_width()
        original_height = image.get_height()

        # poměr zmenšení podle šířky a výšky
        ratio_w = max_width / original_width
        ratio_h = max_height / original_height

        # vezmeme MENŠÍ poměr → aby se vešel celý
        scale_ratio = min(ratio_w, ratio_h)

        new_width = int(original_width * scale_ratio)
        new_height = int(original_height * scale_ratio)

        return pg.transform.smoothscale(image, (new_width, new_height))
    
    
'''class Triko(Item):
    def __init__(self,nazev:str,cena:int,pozice:tuple,pohyblivost:bool,obrazek,obrazek_shop,owned:bool,equiped:bool):
        super().__init__(nazev,cena,pozice,pohyblivost,obrazek,obrazek_shop,owned,equiped)
        self.fit_into_rect(self.obrazek,400,300)
        # vytvoří rect podle obrázku
        self.rect = self.obrazek.get_rect()
        self.rect.topleft = self.pozice'''