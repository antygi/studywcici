# -*- coding: utf-8 -*-
# pygame-exe --py312
# pygbag: width=1600, height=900
import pygame as pg
import json as js
import os
import random
import sys
from itemy import Item
import asyncio
import sys

# Přidáme import pro webové prostředí
if sys.platform == "emscripten":
    import platform


print(pg.__version__)

#iniciace pygame, vytvoření proměnných atd atd
pg.init()

# Definice rozlišení
WIDTH, HEIGHT = 1600, 900
# Vytvoření displeje MUSÍ být první věc po pg.init()
# Na webu nepoužívej pg.RESIZABLE v set_mode, o to se stará CSS v tpml
screen = pg.display.set_mode((WIDTH, HEIGHT))
# Ikona musí být načtena až když existuje display mode

pg.display.set_caption('StudyWithCici')

#----------------------------------------------------
# ------------------------- GLOBALS -----------------
#----------------------------------------------------
#běh
running = True
#čas
clock = pg.time.Clock()
#SAVE FILE
SAVE_FILE = "save.json"

#------------------------- Global FUNKCE -------------------
def get_scaled_mouse_pos():
    """Přepočítá reálnou pozici myši v okně na tvých virtuálních 1600x900"""
    return pg.mouse.get_pos()
    '''ww, wh = window.get_size()
    # Poměr mezi virtuálním rozlišením a aktuální velikostí okna
    return mx * (VIRTUAL_RES[0] / ww), my * (VIRTUAL_RES[1] / wh)'''

def refresh_display():
    """Vezme virtuální plochu, roztáhne ji a vykreslí do reálného okna
    # Změníme velikost virtuálního screenu na velikost okna a blitneme ho
    scaled_surface = pg.transform.scale(screen, window.get_size())
    window.blit(scaled_surface, (0, 0))"""
    pg.display.flip()

#funkce na vytvoření default savu
def vytvor_default_save():
    return {
        "coins": 0,
        "total_cas": 0,
        "owned_items": [cici_default_item.nazev],
        "equipped_items": {     # ← NOVÉ
            "skin": cici_default_item.nazev,
            "triko": None,
            "bryle" : None,
            "maslicka": None,
            "retizek": None
        }
    }


#funkce na vykreslení textu na screen
def vykresliText(text: str,font,barva,x:int,y:int,stred:bool = True,surface=None):
    if surface == None:
        surface = screen
    objektTextu = font.render(text,True,barva,)
    textRect = objektTextu.get_rect()
    textRect.x = x
    textRect.y = y
    if stred == True:
        textRect.center = (x,y)
    surface.blit(objektTextu, textRect)

#zmensi obrazek
def zmensiObrazek(obrazek,velikost: float):
    sirka_obrazek = obrazek.get_width()
    vyska_obrazek = obrazek.get_height()
    nova_velikost_obrazek = (int(sirka_obrazek * velikost), int(vyska_obrazek * velikost))
    obrazek = pg.transform.scale(obrazek, nova_velikost_obrazek)
    return obrazek

#udělá z obrázku miniaturu do obchodu
def fit_into_rect(image:pg.image):
        original_width = image.get_width()
        original_height = image.get_height()

        # poměr zmenšení podle šířky a výšky
        ratio_w = 0.22*589 / original_width
        ratio_h = 0.22*614 / original_height

        # vezmeme MENŠÍ poměr → aby se vešel celý
        scale_ratio = min(ratio_w, ratio_h)

        new_width = int(original_width * scale_ratio)
        new_height = int(original_height * scale_ratio)

        return pg.transform.smoothscale(image, (new_width, new_height))
     
#funkce na uložení savu
def uloz_save(data):
    # 1. Ukládání na webu (localStorage)
    if sys.platform == "emscripten":
        # BEZ ensure_ascii=False
        save_data_str = js.dumps(data) 
        platform.window.localStorage.setItem("studywithcici_save", save_data_str)
        
    # 2. Ukládání lokálně na PC (původní chování)
    else:
        with open(SAVE_FILE, "w", encoding="utf-8") as file:
            js.dump(data, file, indent=4, ensure_ascii=False)

#funkce na načtení savu
def nacti_save():
    data = None
    
    # 1. Pokus o načtení z webového localStorage
    if sys.platform == "emscripten":
        load_data_str = platform.window.localStorage.getItem("studywithcici_save")
        if load_data_str:
            try:
                data = js.loads(load_data_str)
            except js.JSONDecodeError:
                pass # Pokud by byla data z nějakého důvodu poškozená
                
    # 2. Pokud data ještě nemáme (nejsme na webu, nebo je localStorage prázdný)
    if data is None:
        try:
            with open(SAVE_FILE, "r", encoding="utf-8") as file:
                data = js.load(file)
        except FileNotFoundError:
            data = vytvor_default_save()
            uloz_save(data)

    # 3. Oprava starších savů (tvůj původní kód)
    if "equipped_items" not in data:
        data["equipped_items"] = {
            "skin": cici_default_item.nazev,
            "triko": None,
            "bryle": None,
            "maslicka": None,
            "retizek": None
        }
        uloz_save(data)

    return data
    
#---------------- BARVY --------------------------
VANTA_GREEN = (0,255,0)
VANILA = (243,229,171)
GREY = (123,123,125)

#-----------------FONTY------------------------
# Lovely Rose
cesta_L_R  = os.path.join("Fonty", "Lovely Rose.otf")
LOVELY_ROSE = cesta_L_R
b_L_R = pg.font.Font(LOVELY_ROSE,74)
m_L_R = pg.font.Font(LOVELY_ROSE, 44)
s_L_R = pg.font.Font(LOVELY_ROSE, 24)
g_L_R = pg.font.Font(LOVELY_ROSE,104)

# KG Perfect Penmanship
cesta_P_P  = os.path.join("Fonty", "KG Perfect Penmanship.otf")
PERFECT_PENMANSHIP = cesta_P_P
b_P_P = pg.font.Font(PERFECT_PENMANSHIP,74)
m_P_P = pg.font.Font(PERFECT_PENMANSHIP, 44)
s_P_P = pg.font.Font(PERFECT_PENMANSHIP, 24)
g_P_P = pg.font.Font(PERFECT_PENMANSHIP,104)
ug_P_P = pg.font.Font(PERFECT_PENMANSHIP,124)

#-----------------------OBRÁZKY----------------------
#základní pozadí
cesta_k_z_p  = os.path.join("Obrazky", "pozadi.png")
backround = pg.image.load(cesta_k_z_p)
backround = zmensiObrazek(backround,0.625)




#catcoin 
cesta_k_catcoin  = os.path.join("Obrazky", "catcoin.png")
catcoin = pg.image.load(cesta_k_catcoin)
catcoin = zmensiObrazek(catcoin,0.5)
#obchod_button
cesta_k_obchod_button  = os.path.join("Obrazky", "obchod_button.png")
obchod_button = pg.image.load(cesta_k_obchod_button)
obchod_button = zmensiObrazek(obchod_button,0.22)
#learn okno
cesta_k_learn_okno  = os.path.join("Obrazky", "learn_okno.png")
learn_okno = pg.image.load(cesta_k_learn_okno)
learn_okno = zmensiObrazek(learn_okno,1.3)




#-------------------------ITEMY---------------------------
#------ obrázky itemů --------
shop_const = 0.22*0.2
item_const = 0.195
#trika
cesta_k_triko_doktorske  = os.path.join("Obrazky", "triko_doktorske.png")
triko_doktorske_original = pg.image.load(cesta_k_triko_doktorske)
triko_doktorske = zmensiObrazek(triko_doktorske_original,item_const)
triko_doktorske_shop = fit_into_rect(triko_doktorske)

cesta_k_triko_ruzove  = os.path.join("Obrazky", "triko_ruzove.png")
triko_ruzove_original = pg.image.load(cesta_k_triko_ruzove)
triko_ruzove = zmensiObrazek(triko_ruzove_original,item_const)
triko_ruzove_shop = fit_into_rect(triko_ruzove)

#bryle
cesta_k_bryle_kukla  = os.path.join("Obrazky", "bryle_kukla.png")
bryle_kukla_original = pg.image.load(cesta_k_bryle_kukla)
bryle_kukla = zmensiObrazek(bryle_kukla_original,item_const)
bryle_kukla_shop = fit_into_rect(bryle_kukla)

#maslicky
cesta_k_maslicka_hello_kitty  = os.path.join("Obrazky", "maslicka_hello_kitty.png")
maslicka_hello_kitty_original = pg.image.load(cesta_k_maslicka_hello_kitty)
maslicka_hello_kitty = zmensiObrazek(maslicka_hello_kitty_original,item_const)
maslicka_hello_kitty_shop = fit_into_rect(maslicka_hello_kitty)

cesta_k_maslicka_jindra  = os.path.join("Obrazky", "maslicka_jindra.png")
maslicka_jindra_original = pg.image.load(cesta_k_maslicka_jindra)
maslicka_jindra = zmensiObrazek(maslicka_jindra_original,item_const)
maslicka_jindra_shop = fit_into_rect(maslicka_jindra)




#retizky
cesta_k_maslicka_ruzova  = os.path.join("Obrazky", "maslicka_ruzova.png")
maslicka_ruzova_original = pg.image.load(cesta_k_maslicka_ruzova)
maslicka_ruzova = zmensiObrazek(maslicka_ruzova_original,item_const)
maslicka_ruzova_shop = fit_into_rect(maslicka_ruzova)

cesta_k_retizek_perlicky  = os.path.join("Obrazky", "retizek_perlicky.png")
retizek_perlicky_original = pg.image.load(cesta_k_retizek_perlicky)
retizek_perlicky = zmensiObrazek(retizek_perlicky_original,item_const)
retizek_perlicky_shop = fit_into_rect(retizek_perlicky)

#cici 
cesta_k_cici  = os.path.join("Obrazky", "cici.png")
cici = pg.image.load(cesta_k_cici)
cici = zmensiObrazek(cici,0.2)
cici_shop = fit_into_rect(cici)
#hello_kitty_cici
cesta_k_hello_kity_cici  = os.path.join("Obrazky", "hello_kity_cici.png")
hello_kity_cici = pg.image.load(cesta_k_hello_kity_cici)
hello_kitty_cici = zmensiObrazek(hello_kity_cici,0.2)
hello_kitty_cici_shop = fit_into_rect(hello_kitty_cici)

#cici_krava
cesta_k_cici_krava  = os.path.join("Obrazky", "cici_krava.png")
cici_krava = pg.image.load(cesta_k_cici_krava)
cici_krava = zmensiObrazek(cici_krava,0.2)
cici_krava_shop = fit_into_rect(cici_krava)


#-----------------------------
hodina_uceni = 20
list_vsech_itemu = []
vlastnene_itemy = []
slot_cici = (580,355)
slot_item = (slot_cici[0]-7,slot_cici[1]+3)
#trika
triko_doktorske_item = Item('Doktor outfit','triko', 40*hodina_uceni,(slot_item),True,triko_doktorske,triko_doktorske_shop,False,False)
list_vsech_itemu.append(triko_doktorske_item)
triko_ruzove_item = Item('Triko růžové','triko', 3*hodina_uceni,(slot_item),True,triko_ruzove,triko_ruzove_shop,False,False)
list_vsech_itemu.append(triko_ruzove_item)

#bryle
bryle_kukla_item = Item('Gangster kukla','bryle', 3*hodina_uceni,(slot_item),True,bryle_kukla,bryle_kukla_shop,False,False)
list_vsech_itemu.append(bryle_kukla_item)

#retizky
maslicka_ruzova_item = Item('Mašlička růžová','retizek', 2*hodina_uceni,(slot_item),True,maslicka_ruzova,maslicka_ruzova_shop,False,False)
list_vsech_itemu.append(maslicka_ruzova_item)

retizek_perilicky_item = Item('Perličky','retizek', 5*hodina_uceni,(slot_item),True,retizek_perlicky,retizek_perlicky_shop,False,False)
list_vsech_itemu.append(retizek_perilicky_item)

#maslicky
maslicka_hello_kitty_item= Item("Hello kitty mašle", "maslicka", 10*hodina_uceni,(slot_item),False,maslicka_hello_kitty,maslicka_hello_kitty_shop,False,False)
list_vsech_itemu.append(maslicka_hello_kitty_item)
maslicka_jindra_item= Item("Jindřich ze Skalice", "maslicka", 10*hodina_uceni,(slot_item),False,maslicka_jindra,maslicka_jindra_shop,False,False)
list_vsech_itemu.append(maslicka_jindra_item)

#skiny

cici_hello_kitty_item = Item('Čiči Hello Kitty','skin',30*hodina_uceni,slot_cici,False,hello_kitty_cici,hello_kitty_cici_shop,False,False)
list_vsech_itemu.append(cici_hello_kitty_item)
cici_krava_item = Item('Čiči Kráva','skin',15*hodina_uceni,slot_cici,False,cici_krava,cici_krava_shop,False,False)
list_vsech_itemu.append(cici_krava_item)
cici_default_item = Item('Cici default','skin',0,slot_cici,False,cici,cici_shop,True,False)
list_vsech_itemu.append(cici_default_item)



save_data = nacti_save()

# 1. Vynulování vlastnictví a nasazení
for item in list_vsech_itemu:
    item.owned = False
    item.equiped = False

# 2. Obnovení vlastněných itemů
for item in list_vsech_itemu:
    if item.nazev in save_data.get("owned_items", []):
        item.owned = True

# 3. Obnovení nasazených itemů ze savu
skin_nasazen = False
for item in list_vsech_itemu:
    if save_data["equipped_items"].get(item.typ) == item.nazev:
        item.equiped = True
        if item.typ == 'skin':
            skin_nasazen = True

# --- ZÁCHRANNÁ BRZDA ---
# Pokud save neobsahuje validní skin (např. se dříve rozbila diakritika), vynutíme default
if not skin_nasazen:
    cici_default_item.equiped = True
    cici_default_item.owned = True
    save_data["equipped_items"]["skin"] = cici_default_item.nazev
    uloz_save(save_data) # Uložíme opravený stav

# 4. Globální zjištění aktuálního skinu pro jistotu
aktualni_skin = cici_default_item # Další pojistka
for it in list_vsech_itemu:
    if it.typ == 'skin' and it.equiped:
        aktualni_skin = it
        break



#--------------------------------------------------------------
#--------------------- PYGAME FUNKCE --------------------------
#--------------------------------------------------------------

#--------------------funkce na potvrzování-----------------
async def potvrd(text:str,barva,font,moznosti:bool = True):
    global window, is_fullscreen
    mx,my = get_scaled_mouse_pos()
    click = False

    # ------------------- odchod z aplikace ---------------------
    for event in pg.event.get(): #zjišťuje jestli se něco děje
            if event.type == pg.QUIT:
                pg.quit()
                sys.exit()
            if event.type == pg.MOUSEBUTTONDOWN:
                if event.button == 1:
                    click = True

    okno = pg.Rect(500,300,600,300)
    pg.draw.rect(screen,barva, okno)
    vykresliText(text,font,(0,0,0),800,400)

    if moznosti:
        fajvka = pg.Rect(540,520,40,40)
        pg.draw.rect(screen,(0,255,0), fajvka)
        if fajvka.collidepoint((mx,my)):
                    if click == True:
                        return True, False
                    click = False

        krizek = pg.Rect(1020,520,40,40)
        pg.draw.rect(screen,(255,0,0), krizek)
        if krizek.collidepoint((mx,my)):
                    if click == True:
                        return False, False #potvrzeni, beh
                    click = False
    else:
        fajvka = pg.Rect(760,520,40,40)
        pg.draw.rect(screen,(0,255,0), fajvka)
        if fajvka.collidepoint((mx,my)):
                    if click == True:
                        return True, False
                    click = False
    pg.display.flip()
    await asyncio.sleep(0)
    return False, True

'''#--------------------- VYKRESLOVÁNÍ POSTAVY A GADGETŮ -----------------
def vykresli_postavu(surface, skin, overlay_item, pozice):
    surface.blit(skin.obrazek_shop, pozice)
    if overlay_item and overlay_item.typ != "skin":
        surface.blit(overlay_item.obrazek_shop, pozice)'''

#--------------------- FUNKCE SHOP -----------------------
async def shop():
    global window, is_fullscreen
    while running:
        clock.tick(60)
        mx,my = get_scaled_mouse_pos()
        click = False
        myšítka = pg.mouse.get_pressed()
        nasadit = True
        
        #-------------------- zjištění aktuálního skinu ---------
        aktualni_skin = cici_default_item
        for it in list_vsech_itemu:
            if it.typ == "skin" and it.equiped:
                aktualni_skin = it
                break

        # ------------------- odchod z aplikace ---------------------
        for event in pg.event.get(): #zjišťuje jestli se něco děje
                if event.type == pg.QUIT:
                    pg.quit()
                    sys.exit()
                if event.type == pg.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        click = True

        #----------------- POZADÍ -------------------
        screen.blit(backround,(0,0))

        #---------------- NAČTENÍ ČASU -------------------
        total_cas = save_data["total_cas"]
        hours = int(total_cas) // 3600
        minutes = (int(total_cas) % 3600) // 60
        seconds = int(total_cas) % 60
        vykresliText(f"Celkově už se učíš {hours}hodin {minutes}minut a {seconds}sekund",s_P_P,(0,0,0),1300,800)

        #------------------ OBCHODOVÉ OKNO --------------------
        shop = pg.Rect(100,35,1400,830)
        pg.draw.rect(screen,(255,255,255), shop)
        vykresliText('obchod',g_L_R,(0,0,0),800,130)

        krizek = pg.Rect(1400,75,50,50)
        pg.draw.rect(screen,(0,0,0), krizek)
        if krizek.collidepoint((mx,my)):
                if click == True:
                    click = False
                    return
                click = False

        #------------------ VYKRESLENÍ ITEMŮ ---------------------
        # ---- VYKRESLENÍ ITEMŮ V OBCHODĚ ----

        start_x = 250
        start_y = 270
        mezera_x = 250
        mezera_y = 240
        sloupce = 5   # kolik itemů v řádku

        for index, item in enumerate(list_vsech_itemu):
            radek = index // sloupce
            sloupec = index % sloupce

            x = start_x + sloupec * mezera_x
            y = start_y + radek * mezera_y

            ramecek = pg.Rect(x,y,0.22*589,0.22*614)

            if save_data["equipped_items"][item.typ] == item.nazev:
                pg.draw.rect(screen, GREY, ramecek)  # zelený rámeček
                vykresliText("Nasazeno", s_P_P, (0,0,0), x + 70, y + 150) 
            
            elif item.owned:
                pg.draw.rect(screen, VANILA, ramecek)  # zelený rámeček
                vykresliText('Vlastněný',s_P_P,(0,0,0),x + 70,y+150)
               
            else: vykresliText(str(item.cena),s_P_P,(0,0,0),x + 70,y+150,)
            
            vykresliText(f'{item.nazev}',s_P_P,(0,0,0),x+70,y-20)
            
            if item.typ != "skin":
                screen.blit(aktualni_skin.obrazek_shop,(x,y))
                item.draw((x-4,y),screen,True)#x-4
            else: item.draw((x,y),screen,True)

        

        #------ NAKUPOVÁNÍ a NASAZOVÁNÍ ----------
        for item in list_vsech_itemu:
            if item.shop_rect.collidepoint((mx,my)) and click:
                
                if not item.owned:
                    coins = int(save_data["coins"])

                    item.owned, nove_coiny, zprava = item.buy(coins)

                    if item.owned:
                        save_data["coins"] = nove_coiny
                    if item.nazev not in save_data["owned_items"]:
                        save_data["owned_items"].append(item.nazev)

                    uloz_save(save_data)
                else:
                    # pokud kliknu na už nasazený item → sundám ho
                    if save_data["equipped_items"][item.typ] == item.nazev:
                        item.equiped = False
                        save_data["equipped_items"][item.typ] = None
                        if item.typ == 'skin':
                            save_data["equipped_items"][item.typ] = cici_default_item.nazev
                            cici_default_item.equiped = True

                    else:
                        # sundáme starý stejného typu
                        for i in list_vsech_itemu:
                            if i.typ == item.typ:
                                i.equiped = False

                        # nasadíme nový
                        item.equiped = True
                        save_data["equipped_items"][item.typ] = item.nazev

                    uloz_save(save_data)
                    return
    

        #----------------- COINY -----------------------
        pozice_coin_obchod = (110,35)
        screen.blit(catcoin,pozice_coin_obchod)
        coins = save_data['coins']
        vykresliText(str(coins),g_P_P,(0,0,0),pozice_coin_obchod[0]+120,pozice_coin_obchod[1]+15,False)

        pg.display.flip()
        await asyncio.sleep(0)

    






#---------------------- FUNKCE BĚHU PROGRAMU ---------------
async def learn(start_ticks,coins,total_cas):
    global window, is_fullscreen
    

    while running:
        #----------------- LOCALS -------------------------
        clock.tick(60)
        mx,my = get_scaled_mouse_pos()
        click = False
        start_coins = int(coins)
        total_cas = int(total_cas)
        beh_potvrzeni = True
        
        
        # ------------------- odchod z aplikace ---------------------
        for event in pg.event.get(): #zjišťuje jestli se něco děje
                if event.type == pg.QUIT:
                    pg.quit()
                    sys.exit()
                if event.type == pg.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        click = True

        #------------------------ blit pozadí ---------------------------
        screen.blit(backround,(0,0))

        #----------------- HODINY -------------------
        total_seconds = (pg.time.get_ticks() - start_ticks) // 1000

        hours = total_seconds // 3600
        minutes = (total_seconds % 3600) // 60
        seconds = total_seconds % 60

        cas_text = f"{hours:02}:{minutes:02}:{seconds:02}"

        #----------------- LOGIKA PENĚŽ --------------------
        vydelane_coiny = total_seconds // 180
        total_coins = vydelane_coiny + start_coins

        #------------------ UČÍCÍ OKNO S ČASEM --------------------
        pozice_learn_okno = (270,100)
        screen.blit(learn_okno,pozice_learn_okno)
        obdelník = learn_okno.get_rect()
        
        vykresliText(cas_text,ug_P_P,(0,0,0),pozice_learn_okno[0]+150,pozice_learn_okno[1]+100,False)
        if obdelník.collidepoint((mx,my)):
            if click == True:
                coins = int(coins)
                save_data['coins'] = total_coins
                total_cas += total_seconds
                save_data['total_cas'] = total_cas
                uloz_save(save_data)
                while beh_potvrzeni == True:
                    potvrzeni,beh_potvrzeni = await potvrd('Opravdu se chceš přestat učit?',(0,255,255),s_P_P)
                    if potvrzeni:
                        return vydelane_coiny
                    
            click = False
        
        
        pg.display.flip()
        await asyncio.sleep(0)


async def main():
    global window, is_fullscreen
    triko_x  = 800
    triko_y = 450
    

    while running:
        mx,my = get_scaled_mouse_pos()
        click = False
        myšítka = pg.mouse.get_pressed()
        beh_potvrzeni = True
        
        
        # ------------------- odchod z aplikace ---------------------
        for event in pg.event.get(): #zjišťuje jestli se něco děje
                if event.type == pg.QUIT:
                    pg.quit()
                    sys.exit()
                if event.type == pg.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        click = True

        
        #----------------- POZADÍ -------------------
        screen.blit(backround,(0,0))

        #-------------- TLAČÍTKO ZAČNI SE UČIT -----------------
        learn_button = pg.Rect(575,740,450,100)
        pg.draw.rect(screen,(255,255,255), learn_button)
        vykresliText('začni se učit', b_P_P,(0,0,0),800,800)
        #Logika kliknutí
        if learn_button.collidepoint((mx,my)):
            if click == True:
                start_ticks = pg.time.get_ticks()
                vydelane_coiny = await learn(start_ticks,coins,total_cas)
                while beh_potvrzeni == True:
                    if vydelane_coiny > 0:
                        potvrzeni,beh_potvrzeni = await potvrd(f'Vydělal sis {vydelane_coiny} grošů, krásná práce!',VANILA,s_P_P, False)
                    else: potvrzeni,beh_potvrzeni = await potvrd(f'Učil ses bohužel moc krátkou dobu :(',VANILA,s_P_P, False)
                    if potvrzeni:
                        continue
                    
                
            click = False

        

        #----------------- ČIČI --------------------
        for item in list_vsech_itemu:
             if item.typ == 'skin' and item.equiped:
                  screen.blit(item.obrazek,item.pozice)

        #----------------- ITEMY -------------------
        for item in list_vsech_itemu:
            if item.equiped and item.typ != 'skin':
                screen.blit(item.obrazek, item.pozice)

        #----------------- COINY -----------------------
        screen.blit(catcoin,(0,5))
        coins = save_data["coins"]
        vykresliText(str(coins),g_P_P,(0,0,0),120,20,False)

        #---------------- NAČTENÍ ČASU -------------------
        total_cas = save_data["total_cas"]
        hours = int(total_cas) // 3600
        minutes = (int(total_cas) % 3600) // 60
        seconds = int(total_cas) % 60
        vykresliText(f"Celkově už se učíš",s_P_P,(0,0,0),20,820,False)
        vykresliText(f"{hours}hodin {minutes}minut a {seconds}sekund",s_P_P,(0,0,0),20,850,False)
        
        
        #-------------- TLAČÍTKO OBCHOD -------------------
        pozice_shop_button_rect = 30,180,100,100
        pozice_obchod_button = (pozice_shop_button_rect[0] - 15, pozice_shop_button_rect[1] - 25)
        shop_button = pg.Rect(pozice_shop_button_rect)
        screen.blit(obchod_button,pozice_obchod_button)
        #Logika kliknutí
        if shop_button.collidepoint((mx,my)):
            if click == True:
                await shop()
            click = False
        

        '''#------------------ VĚCI Z INVENTÁŘE ---------------
        triko = pg.Rect(triko_x,triko_y,100,100)
        pg.draw.rect(screen,(0,0,0), triko)
        if triko.collidepoint((mx,my)) and myšítka[0]:
                triko_x = mx - 50
                triko_y = my - 50
        '''
        
        pg.display.flip()
        await asyncio.sleep(0)

if __name__ == "__main__":
    asyncio.run(main())